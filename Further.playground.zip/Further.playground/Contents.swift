//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

struct Point {

}

func +=(lhs: inout Point,rhs: Point) {

}//  inout的使用

final class Box<A> {
    var unbox: A
    init(_ value: A) {
        self.unbox = value
    }
}
var x = Box(NSMutableData())
isKnownUniquelyReferenced(&x) // true  /// 改函数用于检查引用的唯一性
var y = x
isKnownUniquelyReferenced(&x) // false

// 写时复制(高效方式)
struct MyData {
    fileprivate var _data: Box<NSMutableData>
    var _dataForWritting: NSMutableData {
        mutating get {
            if isKnownUniquelyReferenced(&_data) {
                _data = Box(_data.unbox.mutableCopy() as! NSMutableData)
                print("Make a copy.")
            }
            return _data.unbox
        }
    }
    init(_ data: NSData) {
        self._data = Box(data.mutableCopy() as! NSMutableData)
    }
}

extension MyData {
    mutating func append(_ other: MyData) {
        _dataForWritting.append(other._data.unbox as Data)
    }
}

let someBytes = MyData(NSData(base64Encoded: "wAEP/w==", options: [])!)
var empty = MyData(NSData())
var emptyCopy = empty
for _ in 0..<5 {
    empty.append(someBytes)
}
empty // <c0010fff c0010fff c0010fff c0010fff c0010fff>
emptyCopy // <>













